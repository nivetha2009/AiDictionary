import { TOOLS } from './data/tools.js'
const FALLBACK = ['chatgpt','claude','gemini','mscopilot']
const PRIORITY = { fast: t => t.ease, quality: t => t.pro, easy: t => t.ease, features: t => t.feats.length + t.pro / 2 }

// Score = about 3-6 points per keyword found (specialised tools and multi-word phrases score higher) + 4 if the chosen task type matches
// + small bonuses for experience level and priority. "match" is the score relative to the best result.
export function recommend(task, f = {}) {
  const q = ' ' + task.toLowerCase().replace(/[^a-z0-9+ ]/g, ' ') + ' '
  let pool = TOOLS.filter(t => !(f.budget === 'free' && t.price === 'Paid'))
  let scored = pool.map(t => {
    const hits = t.kw.filter(k => q.includes(k))
    let s = hits.reduce((n, k) => n + (3 + 3 / t.cats.length) * (k.includes(' ') ? 2 : 1), 0) + (f.type && t.cats.includes(f.type) ? 4 : 0)
    if (s > 0) {
      if (f.level === 'Beginner') s += t.ease * 0.5
      if (f.level === 'Advanced') s += t.pro * 0.5
      if (f.priority) s += PRIORITY[f.priority](t) * 0.6
    }
    return { tool: t, score: s, hits }
  }).filter(r => r.score > 0).sort((a, b) => b.score - a.score)
  let fallback = false
  if (!scored.length) {
    fallback = true
    scored = pool.filter(t => FALLBACK.includes(t.id)).map(t => ({ tool: t, score: 1, hits: [] }))
  }
  const top = scored[0].score
  const results = scored.slice(0, 5).map(r => ({ ...r, match: fallback ? null : Math.max(35, Math.round((r.score / top) * 100 - (r === scored[0] ? 0 : 3))) }))
  const free = results.filter(r => r.tool.price !== 'Paid').sort((a, b) => b.score - a.score)[0]
  const easy = [...results].sort((a, b) => b.tool.ease - a.tool.ease || b.score - a.score)[0]
  const pro = [...results].sort((a, b) => b.tool.pro - a.tool.pro || b.score - a.score)[0]
  return { results, fallback, badges: { best: results[0]?.tool.id, free: free?.tool.id, easy: easy?.tool.id, pro: pro?.tool.id } }
}
