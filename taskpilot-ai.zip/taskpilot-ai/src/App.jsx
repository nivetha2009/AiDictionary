import { useState } from 'react'
import { TOOLS, TASK_TYPES } from './data/tools.js'
import { recommend } from './engine.js'

const EXAMPLES = ['Create a professional resume','Make a PowerPoint from a PDF','Generate MCQs from my study material','Summarise a long research paper','Edit a video for Instagram','Analyse financial data in Excel','Convert a PDF into an educational video','Build a website and publish it on GitHub']
const CATS = TASK_TYPES.filter(t => t !== 'Other')
const BADGES = { best: 'Best overall', free: 'Best free option', easy: 'Easiest for beginners', pro: 'Best for professional use' }

function Card({ r, badges, picked, onPick }) {
  const t = r.tool
  const mine = Object.keys(BADGES).filter(k => badges?.[k] === t.id)
  return (
    <article className="card">
      <div className="top"><div className="ic" aria-hidden>{t.icon}</div><div><h3>{t.name}</h3><span className="tag">{t.price}</span>{mine.map(k => <span key={k} className="tag g">{BADGES[k]}</span>)}</div>
        {r.match != null && <div className="pct">{r.match}%<small>relative match</small></div>}</div>
      <p>{t.desc}</p>
      {r.hits?.length > 0 && <p className="mute"><b>Why it fits:</b> your task mentions {r.hits.slice(0, 4).map(h => `“${h}”`).join(', ')}, which this tool is built for.</p>}
      <ul>{t.feats.map(f => <li key={f}>{f}</li>)}</ul>
      <p className="mute"><b>Limitations:</b> {t.limit}</p>
      <div className="acts"><a className="btn" href={t.url} target="_blank" rel="noopener noreferrer">Visit tool</a>
        <label style={{display:'flex',gap:6,alignItems:'center'}}><input type="checkbox" checked={picked} onChange={() => onPick(t.id)} /> Compare</label></div>
    </article>)
}

export default function App() {
  const [view, setView] = useState('home')
  const [task, setTask] = useState(''); const [f, setF] = useState({})
  const [out, setOut] = useState(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const [recent, setRecent] = useState([]); const [pick, setPick] = useState([]); const [q, setQ] = useState(''); const [cat, setCat] = useState('')
  const set = (k, v) => setF(p => ({ ...p, [k]: v || undefined }))
  const togglePick = id => setPick(p => p.includes(id) ? p.filter(x => x !== id) : p.length < 3 ? [...p, id] : p)

  function run(text = task, filters = f) {
    const s = text.trim()
    if (s.length < 3) { setErr('Describe your task in a few words, for example “make a resume”.'); return }
    if (!/[a-z]/i.test(s)) { setErr('Please describe your task using words.'); return }
    setErr(''); setBusy(true); setOut(null); setView('home')
    setTimeout(() => { const res = recommend(s, filters); setOut({ ...res, task: s }); setBusy(false)
      setRecent(r => [{ task: s, filters, at: Date.now() }, ...r.filter(x => x.task !== s)].slice(0, 8)) }, 450)
  }
  const reset = () => { setTask(''); setF({}); setOut(null); setErr('') }
  const go = v => { setView(v); window.scrollTo(0, 0) }
  const cmp = pick.map(id => TOOLS.find(t => t.id === id))
  const explore = TOOLS.filter(t => (!cat || t.cats.includes(cat)) && (!q || (t.name + t.desc + t.kw.join(' ')).toLowerCase().includes(q.toLowerCase())))

  return (<>
    <nav><div className="wrap"><button className="logo" onClick={() => go('home')}>Task<b>Pilot</b> AI</button>
      {[['home','Home'],['explore','Explore AI Tools'],['compare',`Compare${pick.length ? ` (${pick.length})` : ''}`],['about','About']].map(([k, l]) =>
        <button key={k} className={'nl' + (view === k ? ' on' : '')} onClick={() => go(k)}>{l}</button>)}</div></nav>
    <main className="wrap">
    {view === 'home' && <>
      <section className="hero"><h1>Find the right AI for every task.</h1>
        <p>Describe what you want to get done. TaskPilot matches your words against a catalogue of AI tools and ranks the best fits, with the reasons shown.</p>
        <div className="box"><label htmlFor="t" style={{fontSize:'.95rem',color:'var(--ink)'}}>What do you want to do?</label>
          <textarea id="t" value={task} onChange={e => setTask(e.target.value)} placeholder="e.g. I need to turn my lecture PDF into practice questions" onKeyDown={e => e.key === 'Enter' && (e.metaKey || e.ctrlKey) && run()} />
          {err && <p className="err" role="alert">{err}</p>}
          <div className="row">
            <label>Budget<select value={f.budget || ''} onChange={e => set('budget', e.target.value)}><option value="">Any</option><option value="free">Free plan available</option></select></label>
            <label>Experience<select value={f.level || ''} onChange={e => set('level', e.target.value)}><option value="">Any</option>{['Beginner','Intermediate','Advanced'].map(x => <option key={x}>{x}</option>)}</select></label>
            <label>Priority<select value={f.priority || ''} onChange={e => set('priority', e.target.value)}><option value="">None</option><option value="fast">Fastest workflow</option><option value="quality">Best quality</option><option value="easy">Easiest to use</option><option value="features">Most features</option></select></label>
            <label>Task type<select value={f.type || ''} onChange={e => set('type', e.target.value)}><option value="">Any</option>{TASK_TYPES.map(x => <option key={x}>{x}</option>)}</select></label>
            <button className="btn" onClick={() => run()} disabled={busy}>Find the best AI tools</button>
            <button className="btn ghost" onClick={reset}>Reset</button></div></div>
        <div className="chips" aria-label="Example tasks">{EXAMPLES.map(x => <button key={x} className="chip" onClick={() => { setTask(x); run(x) }}>{x}</button>)}</div>
        <div className="chips" aria-label="Popular categories">{CATS.map(c => <button key={c} className="chip" onClick={() => { const nf = { ...f, type: c }; setF(nf); if (task.trim().length > 2) run(task, nf); else go('explore') || setCat(c) }}>{c}</button>)}</div>
      </section>
      {busy && <div className="spin" role="status" aria-label="Finding tools" />}
      {out && <section aria-live="polite"><h2>Recommended for: “{out.task}”</h2>
        {out.fallback && <p className="mute">No close keyword match, so here are versatile general-purpose assistants. Try adding more detail, such as the file type or the result you want.</p>}
        <div className="grid">{out.results.map((r, i) => <Card key={r.tool.id} r={r} badges={out.badges} picked={pick.includes(r.tool.id)} onPick={togglePick} />)}</div>
        <h2>Why these tools?</h2>
        <div className="box"><p style={{marginTop:0}}>Each tool earns points for every keyword in your task that it is built for, plus points for matching the task type, experience level and priority you chose. The percentage compares each tool with the top result. It is a transparent keyword score, not a live AI judgement. Badges are shown only when they apply to the tools above.</p>
          <ul>{Object.entries(BADGES).filter(([k]) => out.badges[k]).map(([k, l]) => <li key={k}><b>{l}:</b> {TOOLS.find(t => t.id === out.badges[k]).name}</li>)}</ul></div>
        {out.results.length > 1 && <><h2>Alternatives</h2><p className="mute">If the top pick does not suit you, try {out.results.slice(1).map(r => r.tool.name).join(', ')}. Use the Compare checkboxes to see them side by side.</p></>}
      </section>}
      <section><h2>How it works</h2><div className="cols">{[['Describe','Write your task in plain language.'],['Match','We score each tool in the catalogue against your words and filters.'],['Choose','Compare the top tools and open the official site.']].map(([a, b], i) => <div className="card" key={a}><b>{i + 1}. {a}</b><p className="mute">{b}</p></div>)}</div></section>
      {recent.length > 0 && <section><h2>Recent searches <button className="btn ghost" onClick={() => setRecent([])}>Clear history</button></h2>
        <div className="chips">{recent.map(r => <button key={r.at} className="chip" onClick={() => { setTask(r.task); setF(r.filters); run(r.task, r.filters) }}>{r.task}</button>)}</div></section>}
    </>}
    {view === 'explore' && <section><h2>Explore AI tools</h2>
      <div className="row" style={{marginBottom:16}}><label>Search<input value={q} onChange={e => setQ(e.target.value)} style={{padding:8,borderRadius:8,border:'1px solid var(--line)'}} /></label>
        <label>Category<select value={cat} onChange={e => setCat(e.target.value)}><option value="">All</option>{TASK_TYPES.map(x => <option key={x}>{x}</option>)}</select></label></div>
      <div className="grid">{explore.map(t => <Card key={t.id} r={{ tool: t }} picked={pick.includes(t.id)} onPick={togglePick} />)}{!explore.length && <p>No tools match. Clear the search or pick another category.</p>}</div></section>}
    {view === 'compare' && <section><h2>Compare tools</h2>
      {cmp.length < 2 ? <p>Select two or three tools using the Compare checkboxes on the Home or Explore pages.</p> :
        <div className="scroll"><table><thead><tr><th />{cmp.map(t => <th key={t.id}>{t.icon} {t.name}</th>)}</tr></thead><tbody>
          {[['Main purpose', t => t.desc], ['Best for', t => t.cats.join(', ')], ['Key features', t => t.feats.join('; ')], ['Pricing category', t => t.price], ['Ease of use', t => `${t.ease}/5`], ['Advanced power', t => `${t.pro}/5`], ['Limitations', t => t.limit], ['Official site', t => <a href={t.url} target="_blank" rel="noopener noreferrer">Visit</a>]].map(([l, fn]) =>
            <tr key={l}><th scope="row">{l}</th>{cmp.map(t => <td key={t.id}>{fn(t)}</td>)}</tr>)}</tbody></table></div>}
      {pick.length > 0 && <p><button className="btn ghost" onClick={() => setPick([])}>Clear selection</button></p>}</section>}
    {view === 'about' && <section><h2>About TaskPilot AI</h2><div className="box">
      <p>TaskPilot AI recommends AI tools using a local, keyword-based matching engine and a hand-written catalogue. No live AI model is connected and no account is needed.</p>
      <p>Pricing categories, features and limits can change. Always confirm details on the official site before paying. Ease and power ratings are editorial judgements.</p></div></section>}
    </main>
    <footer><div className="wrap">TaskPilot AI is an independent guide and is not affiliated with the listed tools. Tool details may be out of date; check each official website.</div></footer>
  </>)
}
