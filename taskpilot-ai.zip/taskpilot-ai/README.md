# TaskPilot AI

Describe a task, get ranked AI tool recommendations with reasons, filters, side-by-side comparison and session-only recent searches. React + Vite, no backend, no API keys.

**How recommendations work:** a local keyword-scoring engine (`src/engine.js`) matches your task against the catalogue in `src/data/tools.js`. It is not a live AI model. Prices/limits are general categories and may be outdated, so verify on official sites.

## Run locally
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # outputs dist/
npm run preview
```

## Deploy on GitHub Pages
1. Create a GitHub repository and push this project to the `main` branch.
2. In the repo, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main`. The workflow in `.github/workflows/deploy.yml` builds and publishes the site.
4. Your site appears at `https://<username>.github.io/<repo>/`.

`vite.config.js` uses `base: './'`, so no repository-specific path is needed. The app has no router, so refreshes never 404.

## Update the catalogue
Edit `src/data/tools.js`: add an object with `id, name, icon, url, cats, kw, desc, feats, price, limit, ease, pro`. Only use official URLs.

## Optional AI integration (not included)
To add a live model, build a small serverless API (Vercel, Netlify or Cloudflare Workers) that holds the key in an environment variable and call it from the frontend. Never put keys in this repo. The local engine stays as the fallback.
